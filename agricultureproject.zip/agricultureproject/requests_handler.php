<?php

/**
 * requests_handler.php
 * POST endpoint for the approval queue (Admin only).
 *
 * Expects:
 *   request_id  int
 *   decision    'APPROVE' | 'REJECT'
 *
 * On APPROVE:
 *   - UPDATE action → applies proposed_data JSON to target_table WHERE record_id
 *   - DELETE action → deletes the row from target_table WHERE record_id
 *   - Sets change_requests.status = 'APPROVED'
 *
 * On REJECT:
 *   - Sets change_requests.status = 'REJECTED' only (no main-table change)
 */

session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

/* ── Auth guard ─────────────────────────────────────────── */
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Not authenticated.']);
    exit;
}
if (!isAdmin()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Forbidden. Admin only.']);
    exit;
}

/* ── Input validation ───────────────────────────────────── */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed.']);
    exit;
}

$requestId = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT);
$decision  = strtoupper(trim($_POST['decision'] ?? ''));

if (!$requestId || !in_array($decision, ['APPROVE', 'REJECT'], true)) {
    echo json_encode(['ok' => false, 'error' => 'Invalid input.']);
    exit;
}

/* ── Fetch the change_request row ───────────────────────── */
$stmt = $pdo->prepare("
    SELECT * FROM change_requests
    WHERE  request_id = :id AND status = 'PENDING'
    LIMIT  1
");
$stmt->execute([':id' => $requestId]);
$req = $stmt->fetch();

if (!$req) {
    echo json_encode(['ok' => false, 'error' => 'Request not found or already processed.']);
    exit;
}

/* ── Whitelist of modifiable tables ─────────────────────── */
$allowedTables = ['farmer', 'farm', 'crop', 'planting', 'harvest'];

$targetTable = $req['target_table'];
if (!in_array($targetTable, $allowedTables, true)) {
    echo json_encode(['ok' => false, 'error' => 'Target table not allowed.']);
    exit;
}

/* ── Determine the primary key column per table ─────────── */
$pkMap = [
    'farmer'   => 'farmer_id',
    'farm'     => 'farm_id',
    'crop'     => 'crop_id',
    'planting' => 'planting_id',
    'harvest'  => 'harvest_id',
];
$pkCol    = $pkMap[$targetTable];
$recordId = (int)$req['record_id'];

/* ── Execute decision ───────────────────────────────────── */
try {
    $pdo->beginTransaction();

    if ($decision === 'APPROVE') {
        $actionType = strtoupper($req['action_type']);

        if ($actionType === 'UPDATE') {
            $proposedData = json_decode($req['proposed_data'], true);

            if (!is_array($proposedData) || empty($proposedData)) {
                throw new RuntimeException('proposed_data is empty or invalid JSON.');
            }

            // Build SET clause dynamically using the whitelisted table
            // Column names are sanitized: only alphanumeric + underscore allowed
            $setClauses = [];
            $params     = [];
            foreach ($proposedData as $col => $val) {
                if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $col)) {
                    throw new RuntimeException("Invalid column name: {$col}");
                }
                $placeholder         = ":col_{$col}";
                $setClauses[]        = "\"{$col}\" = {$placeholder}";
                $params[$placeholder] = $val;
            }
            $params[':record_id'] = $recordId;

            $sql = "UPDATE \"{$targetTable}\" SET " . implode(', ', $setClauses)
                 . " WHERE \"{$pkCol}\" = :record_id";

            $pdo->prepare($sql)->execute($params);

        } elseif ($actionType === 'DELETE') {
            $sql = "DELETE FROM \"{$targetTable}\" WHERE \"{$pkCol}\" = :record_id";
            $pdo->prepare($sql)->execute([':record_id' => $recordId]);

        } else {
            throw new RuntimeException("Unknown action_type: {$actionType}");
        }

        // Mark as APPROVED
        $pdo->prepare("
            UPDATE change_requests
            SET    status = 'APPROVED', reviewed_at = NOW(), reviewed_by = :admin_id
            WHERE  request_id = :id
        ")->execute([':admin_id' => $_SESSION['user_id'], ':id' => $requestId]);

        $pdo->commit();
        echo json_encode(['ok' => true, 'message' => 'Request approved and changes applied.']);

    } else {
        // REJECT — only update status
        $pdo->prepare("
            UPDATE change_requests
            SET    status = 'REJECTED', reviewed_at = NOW(), reviewed_by = :admin_id
            WHERE  request_id = :id
        ")->execute([':admin_id' => $_SESSION['user_id'], ':id' => $requestId]);

        $pdo->commit();
        echo json_encode(['ok' => true, 'message' => 'Request rejected.']);
    }

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['ok' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
